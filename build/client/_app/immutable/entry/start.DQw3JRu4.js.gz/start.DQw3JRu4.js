import{a as t}from"../chunks/entry.9G8Zeza6.js";export{t as start};
